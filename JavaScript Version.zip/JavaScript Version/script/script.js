var gErrorMsg = "";

function displayHouse(){
	/*house array and value array are arrange in order, ex: house[0]=value[0]*/
	var house = ["Sweet Home Viva City Megamall Jazz Suites", "Cosy Apartment", "The Charcoal", "Riverbank Suites", "Boyan Heights Rainforest", "Hibiscus Beach Retreat", "Sunbeam Luxury Villa", "Riverson Soho", "Sutera Avenue Suite", "Imago Luxurious Room", "Dr.Shaz Summer House", "7 Pax Studio", "The Scott Garden", "The Nordic", "Home Wood", "The Happiness Home 2", "Cozy Family Suites", "All-You-Need Duplex", "PJ New Suite Studio", "ASR Neo Damansara"];
	var value = ["Sweet Home Viva City Megamall Jazz Suites", "Cosy Apartment", "The Charcoal", "Riverbank Suites", "Boyan Heights Rainforest", "Hibiscus Beach Retreat", "Sunbeam Luxury Villa", "Riverson Soho", "Sutera Avenue Suite", "Imago Luxurious Room", "Dr.Shaz Summer House", "7 Pax Studio", "The Scott Garden", "The Nordic", "Home Wood", "The Happiness Home 2", "Cozy Family Suites", "All-You-Need Duplex", "PJ New Suite Studio", "ASR Neo Damansara"];
	var x;
	
	for(x = 0; x < 20; x++){
		/*Create new option in every loop*/
		var node = document.createElement("option");
		/*Create the content from array*/
		var textnode = document.createTextNode(house[x]);
		/*<option> tag is appending a child content from text node*/
		node.appendChild(textnode);
		/*Append the <option>textnode</option> inside the ID "house" (<select></select> tag)*/
		document.getElementById("house").appendChild(node);
		/*Set the value for the <option value="x"> tag according to array value, first <option> tag use first value, ex: ("option")[0]=value[0]*/
		document.getElementById("house").getElementsByTagName("option")[x].setAttribute("value", value[x]);
	}
}

function storeHouse(){
	sessionStorage.house = document.getElementById("house").value;
	document.getElementById("subject").value = "RE: Enquiry on " + sessionStorage.house;
}

function nameStore(){
	sessionStorage.title = document.getElementById("pTitle").textContent;
}
	
function validateForm(){
	"use strict"
	var isAllOK = false;
	gErrorMsg = "";
	var fnameOK = checkFirstName();
	var lnameOK = checkLastName();
	var emailOK = checkEmail();
	var phoneOK = checkPhone();
	var houseOK = checkHouse();
	var timeOK = checkTime();
	var addressOK = checkAddress();
	var cityOK = checkCity();
	var postOK = checkPostcode();
	if(fnameOK && lnameOK && emailOK && phoneOK && houseOK && timeOK && addressOK && cityOK && postOK)
	{
		isAllOK=true;
	}
	else
	{
		alert(gErrorMsg);
		gErrorMsg = "";
		isAllOK = false;
	}
	return isAllOK;
}

function checkFirstName(){
	var name = document.getElementById("first").value;
	var isOk = true;
	if(name.length == 0){
		gErrorMsg = gErrorMsg + "Your first name cannot be blank\n";
		isOk = false;
	}
	return isOk;
}

function checkLastName(){
	var name = document.getElementById("last").value;
	var isOk = true;
	if(name.length == 0){
		gErrorMsg = gErrorMsg + "Your last name cannot be blank\n";
		isOk = false;
	}
	return isOk;
}

function checkEmail(){
	var emailRE = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-za-zA-Z0-9.-]{1,4}$/;
	var email = document.getElementById("email");
	var isOk = false;
	if(emailRE.test(email.value)){
		isOk = true;
	}
	else{
		gErrorMsg = gErrorMsg + "Enter valid email address\n";
		isOk = false;
	}
	return isOk;
}

function checkPhone(){
	var phoneRE = /\d{3}\d{6,7}/;
	var phone = document.getElementById("phone");
	var isOk = false;
	if(phoneRE.test(phone.value)){
		isOk = true;
	}
	else{
		gErrorMsg = gErrorMsg + "Please follow the phone format\n";
		isOk = false;
	}
	return isOk;
}

function checkHouse(){
	var selected = false;
	var house = document.getElementById("house").value;
	if(house != "none"){
		selected = true;
	}
	else{
		selected = false;
		gErrorMsg = gErrorMsg + "House have to be selected, cannot left it empty or not selected";
	}
	return selected;
}

function checkTime(){
	var isOk = false;
	var time = document.getElementById("time");
	if(time.value>=1){
		isOk = true;
	}
	else{
		isOk = false;
		gErrorMsg = gErrorMsg + "Your rental duration cannot be less than 1 day\n";
	}
	return isOk;
}

function checkAddress(){
	var street = document.getElementById("street").value;
	var isOk = true;
	if(street.length == 0){
		gErrorMsg = gErrorMsg + "Your street address cannot be blank\n";
		isOk = false;
	}
	return isOk;
}

function checkCity(){
	var city = document.getElementById("city").value;
	var isOk = true;
	if(city.length == 0){
		gErrorMsg = gErrorMsg + "Your city cannot be blank\n";
		isOk = false;
	}
	return isOk;
}

function checkPostcode(){
	var isOk = false;
	var postRE = /\d{5}/;
	var post = document.getElementById("postcode");
	if(postRE.test(post.value)){
		isOk = true;
	}
	else{
		gErrorMsg = gErrorMsg + "Please follow postcode format\n";	
		isOk = false;
	}
	return isOk;
}

function init(){
	displayHouse();
	
	document.getElementById("subject").value = "RE: Enquiry on " + sessionStorage.title;
	
	var regForm = document.getElementById("form");
	regForm.onsubmit = validateForm; /*script trigger when click on submit in form*/
	
	
}

window.onload = init; /*script start when window is load*/