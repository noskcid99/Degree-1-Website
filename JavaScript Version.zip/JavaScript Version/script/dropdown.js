function displayNavDrop(){
	var state = ["Sarawak", "Sabah", "Pahang", "Selangor"];
	var hyperLinkState = ["sarawak.html", "sabah.html", "pahang.html", "selangor.html"];
	var about = ["Siaw Zhen", "Dickson", "Wilson", "Peng"];
	var hyperLinkAbout = ["aboutme1.html", "aboutme2.html", "aboutme3.html", "aboutme4.html"];
	var x;
	
	for(x = 0; x < 4; x++){
		var nodeState = document.createElement("a");
		var nodeAbout = document.createElement("a");
		var textnodeState = document.createTextNode(state[x]);
		var textnodeAbout = document.createTextNode(about[x]);
		nodeState.appendChild(textnodeState);
		nodeAbout.appendChild(textnodeAbout);
		document.getElementById("dropdown-state").appendChild(nodeState);
		document.getElementById("dropdown-about").appendChild(nodeAbout);
		document.getElementById("dropdown-state").getElementsByTagName("a")[x].setAttribute("href", hyperLinkState[x]);
		document.getElementById("dropdown-about").getElementsByTagName("a")[x].setAttribute("href", hyperLinkAbout[x]);
	}
}

window.addEventListener("load", displayNavDrop);